## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----klippy, echo=FALSE, include=TRUE-----------------------------------------
klippy::klippy(position = c("top", "right"))

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  utils::install.packages(
#    pkgs = "https://github.com/barnzilla/r-package-sources/raw/master/capl_1.0.tar.gz",
#    repos = NULL,
#    type = "source"
#  )
#  library(capl)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  devtools::install_github("barnzilla/capl", upgrade = "never", build_vignettes = TRUE, force = TRUE)
#  library(capl)

## ----warning = FALSE, message = FALSE, echo = FALSE---------------------------
library(capl)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  browseVignettes("capl")

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  ?get_missing_capl_variables()

## ----warning = FALSE, message = FALSE-----------------------------------------
data(capl_demo_data)

## ----warning = FALSE, message = FALSE-----------------------------------------
str(capl_demo_data)

## ----warning = FALSE, message = FALSE-----------------------------------------
colnames(capl_demo_data)

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data2 <- get_capl_demo_data(n = 10000)

## ----warning = FALSE, message = FALSE-----------------------------------------
str(capl_demo_data2)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  # Install the package
#  install.packages("writexl")

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  # Load the package
#  library(writexl)
#  
#  # Export object to Excel
#  write_xlsx(capl_demo_data2, "c:/users/joel/desktop/capl_demo_data2.xlsx")

## -----------------------------------------------------------------------------
# Create fake data
raw_data <- data.frame(
  age_years = sample(8:12, 100, replace = TRUE),
  genders = sample(c("girl", "boy"), 100, replace = TRUE, prob = c(0.51, 0.49)),
  step_counts1 = sample(1000:30000, 100, replace = TRUE),
  step_counts2 = sample(1000:30000, 100, replace = TRUE),
  step_counts3 = sample(1000:30000, 100, replace = TRUE),
  step_counts4 = sample(1000:30000, 100, replace = TRUE),
  step_counts5 = sample(1000:30000, 100, replace = TRUE),
  step_counts6 = sample(1000:30000, 100, replace = TRUE),
  step_counts7 = sample(1000:30000, 100, replace = TRUE)
)

# Examine the structure of this data
str(raw_data)

# Rename the variables
raw_data <- rename_variable(
  x = raw_data,
  search = colnames(raw_data),
  replace = c("age", "gender", "steps1", "steps2", "steps3", "steps4", "steps5", "steps6", "steps7")
)

# Examine the structure of this data
str(raw_data)

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_results <- get_capl(raw_data = capl_demo_data, sort = "abc")

## -----------------------------------------------------------------------------
str(capl_results, list.len = nrow(capl_results))

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data$pacer_laps_20m <- get_pacer_20m_laps(
  lap_distance = capl_demo_data$pacer_lap_distance, 
  laps_run = capl_demo_data$pacer_laps
)

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data$pacer_laps_20m

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data$pacer_score <- get_pacer_score(capl_demo_data$pacer_laps_20m)

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data$pacer_score

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data$pacer_interpretation <- get_capl_interpretation(
  age = capl_demo_data$age,
  gender = capl_demo_data$gender,
  score = capl_demo_data$pacer_score,
  protocol = "pacer"
)

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data$pacer_interpretation

## ----warning = FALSE, message = FALSE-----------------------------------------
validate_gender(c("Girl", "GIRL", "g", "G", "Female", "f", "F", "", NA, 1))

## ----warning = FALSE, message = FALSE-----------------------------------------
validate_gender(c("Boy", "BOY", "b", "B", "Male", "m", "M", "", NA, 0))

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data$plank_score <- get_plank_score(capl_demo_data$plank_time)

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data$plank_score

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data$plank_interpretation <- get_capl_interpretation(
  age = capl_demo_data$age,
  gender = capl_demo_data$gender,
  score = capl_demo_data$plank_time,
  protocol = "plank"
)

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data$plank_interpretation

## ----warning = FALSE, message = FALSE-----------------------------------------
validate_gender(c("Girl", "GIRL", "g", "G", "Female", "f", "F", "", NA, 1))

## ----warning = FALSE, message = FALSE-----------------------------------------
validate_gender(c("Boy", "BOY", "b", "B", "Male", "m", "M", "", NA, 0))

## ----warning = FALSE, message = FALSE-----------------------------------------
# Trial 1
capl_demo_data$camsa_time_score1 <- get_camsa_time_score(capl_demo_data$camsa_time1)

# Trial 2
capl_demo_data$camsa_time_score2 <- get_camsa_time_score(capl_demo_data$camsa_time2)

## ----warning = FALSE, message = FALSE-----------------------------------------
# Time scores for trial 1
capl_demo_data$camsa_time_score1

## ----warning = FALSE, message = FALSE-----------------------------------------
# Time scores for trial 2
capl_demo_data$camsa_time_score2

## ----warning = FALSE, message = FALSE, fig.width = 7.25, fig.height = 7.25----
get_score_by_interpretation_plot(
  score = capl_results$pc_score,
  interpretation = capl_results$pc_interpretation,
  x_label = "Interpretation",
  y_label = "Physical competence domain score (/30)"
)

## ----warning = FALSE, message = FALSE, fig.width = 7.25, fig.height = 7.25----
get_score_by_interpretation_plot(
  score = capl_results$db_score,
  interpretation = capl_results$db_interpretation,
  x_label = "Interpretation",
  y_label = "Daily behaviour domain score (/30)",
  colors = c("#daf7a6", "#ffc300", "#ff5733", "#c70039")
)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  # Install the package
#  install.packages("writexl")

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  # Load the package
#  library(writexl)
#  
#  # Export object to Excel
#  write_xlsx(capl_results, "c:/users/joel/desktop/capl_results.xlsx")

