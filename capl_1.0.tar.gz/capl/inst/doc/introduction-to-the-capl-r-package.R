## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----klippy, echo=FALSE, include=TRUE-----------------------------------------
klippy::klippy(position = c("top", "right"))

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  devtools::install_github("barnzilla/capl", upgrade = "never")
#  library(capl)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  utils::install.packages(
#    pkgs = "https://github.com/barnzilla/r-package-sources/raw/master/capl_1.0.tar.gz",
#    repos = NULL,
#    type = "source"
#  )
#  library(capl)

## ----warning = FALSE, message = FALSE, echo = FALSE---------------------------
library(capl)

## ----warning = FALSE, message = FALSE-----------------------------------------
data(capl_demo_data)

## ----warning = FALSE, message = FALSE-----------------------------------------
str(capl_demo_data)

## ----warning = FALSE, message = FALSE-----------------------------------------
capl_demo_data2 <- get_capl_demo_data(n = 10000)

## ----warning = FALSE, message = FALSE-----------------------------------------
str(capl_demo_data2)

