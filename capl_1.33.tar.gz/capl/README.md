# capl
R package for use with data collected using the Canadian Assessment of Physical Literacy. The package contains functions that will calculate CAPL scores and interpretations from raw data.
