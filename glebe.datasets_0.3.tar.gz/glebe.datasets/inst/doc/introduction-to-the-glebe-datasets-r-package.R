## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----klippy, echo = FALSE, include = TRUE-------------------------------------
klippy::klippy(position = c("top", "right"))

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  utils::install.packages(
#    pkgs = "https://github.com/barnzilla/r-package-sources/raw/master/glebe.datasets_0.2.tar.gz",
#    repos = NULL,
#    type = "source"
#  )
#  library(glebe.datasets)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  devtools::install_github("barnzilla/glebe.datasets", upgrade = "never", build_vignettes = TRUE, force = TRUE)
#  library(glebe.datasets)

## ----warning = FALSE, message = FALSE, echo = FALSE---------------------------
library(glebe.datasets)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  browseVignettes("glebe.datasets")

## -----------------------------------------------------------------------------
data <- get_dataset(n = 500)

## -----------------------------------------------------------------------------
str(data)

