## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----klippy, echo = FALSE, include = TRUE, eval = FALSE-----------------------
#  klippy::klippy(position = c("top", "right"))

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  utils::install.packages(
#    pkgs = "https://github.com/barnzilla/r-package-sources/raw/master/glebe.datasets_0.6.tar.gz",
#    repos = NULL,
#    type = "source"
#  )
#  library(glebe.datasets)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  devtools::install_github("barnzilla/glebe.datasets", upgrade = "never", build_vignettes = TRUE, force = TRUE)
#  library(glebe.datasets)

## ----warning = FALSE, message = FALSE, echo = FALSE---------------------------
library(glebe.datasets)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  browseVignettes("glebe.datasets")

## -----------------------------------------------------------------------------
demo_dataset <- get_dataset(n = 500)

## -----------------------------------------------------------------------------
str(demo_dataset)

## ----eval = FALSE-------------------------------------------------------------
#  export_dataset(
#    demo_dataset,
#    path = "c:/users/joel/desktop/demo_dataset.xlsx",
#    type = "spss"
#  )
#  
#  export_dataset(
#    demo_dataset,
#    path = "c:/users/joel/desktop/demo_dataset.spss",
#    type = "spss"
#  )

