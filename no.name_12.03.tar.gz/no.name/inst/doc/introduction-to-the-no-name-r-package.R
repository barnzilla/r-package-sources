## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----klippy, echo=FALSE, include=TRUE-----------------------------------------
klippy::klippy(position = c("top", "right"))

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  devtools::install_github("barnzilla/no.name", upgrade = "never")
#  library(no.name)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  utils::install.packages(
#    pkgs = "https://github.com/barnzilla/r-package-sources/raw/master/no.name_12.03.tar.gz",
#    repos = NULL,
#    type = "source"
#  )
#  library(no.name)

## ----warning = FALSE, message = FALSE, echo = FALSE---------------------------
library(no.name)

## -----------------------------------------------------------------------------
model.1.workbook <- get.path("demo.model.1.xls")

## -----------------------------------------------------------------------------
model.1.workbook <- get.path("demo.model.1.xls")

## -----------------------------------------------------------------------------
sheet.names <- list(
  parms.notime.0d = "Parameters any time any age",
  parms.0d = "Parameters any age",
  parms.1d = "Parameters by Age",
  parms.2d = "Parameters by Age x Age",
  initial.conditions = "Initial conditions",
  model.flow = "Model Specs (not lazy v1)",
  auxiliary.vars = "Intermediate calculations",
  post.processing = "Post Processing Empty"
)

## -----------------------------------------------------------------------------
results.not.lazy.1 <- seir.n.age.classes(model.1.workbook, sheet.names)

## -----------------------------------------------------------------------------
results.not.lazy.1$input.info$model.flow[, c("From", "To", "lazy", "activation", "expression")]

results.not.lazy.1$input.info$auxiliary.vars

results.not.lazy.1$input.info$initial.conditions

results.not.lazy.1$input.info$parms.notime.0d

results.not.lazy.1$input.info$parms.0d

results.not.lazy.1$input.info$parms.1d

results.not.lazy.1$input.info$parms.2d

results.not.lazy.1$input.info$post.processing

## -----------------------------------------------------------------------------
# Lazy model
sheet.names$model.flow <- "Model Specs (lazy)"
results.lazy <- seir.n.age.classes(model.1.workbook, sheet.names)

# Not lazy v2 model
sheet.names$model.flow <- "Model Specs (not lazy v2)"
results.not.lazy.2 <- seir.n.age.classes(model.1.workbook, sheet.names)

# Not lazy v3 model
sheet.names$model.flow <- "Model Specs (not lazy v3)"
results.not.lazy.3 <- seir.n.age.classes(model.1.workbook, sheet.names)

## -----------------------------------------------------------------------------
head(results.not.lazy.1$solution)

get.scatter.plot(
  results.not.lazy.1$solution$time,
  results.not.lazy.1$solution$Left, 
  height = 500, 
  width = 756
)
results.not.lazy.1$sommaire

## -----------------------------------------------------------------------------
sheet.names$model.flow <- "Model Specs (lazy)"
sheet.names$post.processing <- "Post Processing"
results.lazy <- seir.n.age.classes(model.1.workbook, sheet.names)

## -----------------------------------------------------------------------------
cat(paste(results.lazy$input.info$post.processing$code, collapse = "\n"))

## -----------------------------------------------------------------------------
results.lazy$sommaire

## -----------------------------------------------------------------------------
head(results.lazy$solution) 

## -----------------------------------------------------------------------------
range(results.not.lazy.1$solution - results.lazy$solution[,-4])

## -----------------------------------------------------------------------------
range(results.not.lazy.2$solution - results.lazy$solution[,-4])

## -----------------------------------------------------------------------------
range(results.not.lazy.3$solution - results.lazy$solution[,-4])

