## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  devtools::install_github("barnzilla/no.name", upgrade = "never")
#  library(no.name)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  utils::install.packages(
#    pkgs = "https://github.com/barnzilla/r-package-sources/raw/master/no.name_12.04.tar.gz",
#    repos = NULL,
#    type = "source"
#  )
#  library(no.name)

## ----warning = FALSE, message = FALSE, echo = FALSE---------------------------
library(no.name)

