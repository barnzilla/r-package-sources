## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  devtools::install_github("barnzilla/no.name", upgrade = "never", build_vignettes = TRUE)
#  library(no.name)

## ----warning = FALSE, message = FALSE, eval = FALSE---------------------------
#  utils::install.packages(
#    pkgs = "https://github.com/barnzilla/r-package-sources/raw/master/no.name_12.04.tar.gz",
#    repos = NULL,
#    type = "source"
#  )
#  library(no.name)

## ----warning = FALSE, message = FALSE, echo = FALSE---------------------------
library(no.name)

## -----------------------------------------------------------------------------
file.name <- get.path("phac.model.xls")

## -----------------------------------------------------------------------------
sheet.names = list(
  initial.conditions = "Initial conditions",
  parms.notime.0d = "Parameters any time any age", 
  parms.0d = "Parameters any age",
  parms.1d = "Parameters by Age",
  parms.2d = "Parameters by Age x Age",
  model.flow ="Model Specs (not lazy)",
  auxiliary.vars = "Intermediate calculations",
  post.processing = "Post Processing"
)

## -----------------------------------------------------------------------------
target.file <- get.path("canadian.covid.19.data.xls")

## -----------------------------------------------------------------------------
target.df <- as.data.frame(readxl::read_excel(target.file, sheet = "Canadian data"))

# Create a new column from the Deaths columns
target.df$D <- target.df$Deaths

## -----------------------------------------------------------------------------
# Interested in cumIconfirmed and D
covid.targets <- list(donnees = target.df[c("time","cumIconfirmed","D")])

# Interested in five time periods: days 30-39, 40-49, 50-59, 60-69, 70-75
covid.targets$time.ranges <- data.frame(lower.bound = 20 +10 * seq(5))

## -----------------------------------------------------------------------------
# Interested in cumIconfirmed
covid.targets <- list(donnees = target.df[c("time","cumIconfirmed")])    

# Interested in one time: day 75
covid.targets$time.ranges <- data.frame(lower.bound = 75, upper.bound = 75)

## -----------------------------------------------------------------------------
# Interested in cumIconfirmed
covid.targets <- list(donnees = target.df[c("time","cumIconfirmed")])                     

# Interested in three times: days 47, 88, 175
covid.targets$time.ranges <- data.frame(
  lower.bound = c(47, 88, 175),
  upper.bound = c(47, 88, 175)
)  

## -----------------------------------------------------------------------------
# Interested in cumIconfirmed1, cumIconfirmed2, ..., cumIconfirmed6
covid.targets <- list(donnees = target.df[c("time", paste0("cumIconfirmed", 1:6))])         

# Interested in three times: days 47, 88, 175
covid.targets$time.ranges <- data.frame(
  lower.bound = c(47, 88, 175),
  upper.bound = c(47, 88, 175)
)

## -----------------------------------------------------------------------------
hypercube.specs <- read.hypercube.sampling.specs(
  file.name, 
  sheet = "HyperCube Sampling Specs"
) 

parm.cloud.grid.specs <- list(
  hypercube.lower.bounds = hypercube.specs$lower.bound,
  hypercube.upper.bounds = hypercube.specs$upper.bound,
  hypercube.apex.mode    = hypercube.specs$apex , # To be commented if uniform
  n.repeat.within.hypercube = 4, # 10000, icitte
  LatinHypercubeSampling = c(FALSE, TRUE)[2],
  racine = 123,
  backend.transformation = function(x) {x}, # Need to provide a function like exp here
  reference.alteration = c("overwrite", "add", "multiply")[1],
  tmin.alter.scope = 0:1000
)

## -----------------------------------------------------------------------------
results.baseline <- seir.n.age.classes(
  file.name,
  sheet.names,
  functions.kit = list(
    post.processing.companion.kit = list(targets = covid.targets)
  )
)

## -----------------------------------------------------------------------------
str(parm.cloud.grid.specs) 

take.a.quick.look <- try.various.parms.values(
  results.baseline,
  parm.cloud.grid.specs,
  only.show.parms.to.try = TRUE
)

# Check size of the parameter sweep about to be undertaken (e.g., number of scenarios, number of parameters)
dim(take.a.quick.look$parms.to.try)  

## -----------------------------------------------------------------------------
various.parms.result <- try.various.parms.values(
  results.baseline,
  parm.cloud.grid.specs
)

## -----------------------------------------------------------------------------
parms.tried.df <- various.parms.result$parms.to.try
list.sweep <- various.parms.result$list.sweep
df.sweep<- various.parms.result$df.sweep
outcomes.summary.df <- various.parms.result$outcomes.summary.df

## ----eval = FALSE-------------------------------------------------------------
#  # This creates a file named "This file contains an R object called list.sweep.SavedFromR". Use load() to load this back into the R global environment.
#  verbose.save("list.sweep")
#  verbose.save("df.sweep")
#  verbose.save("outcomes.summary.df")
#  verbose.save("parms.tried.df")

## -----------------------------------------------------------------------------
get.scatter.plot(
   x = outcomes.summary.df$lambda_Period1.overwrite,
   y = outcomes.summary.df$AR,
   x_label_text = "Lambda",
   y_label_text = "AR",
   height = 500,
   width = 756
 )

## ----eval = FALSE-------------------------------------------------------------
#  # Render a tornado plot
#   get.tornado.plot(
#     outcome_variable = "AR",
#     parameters = parms.tried.df,
#     outcomes = outcomes.summary.df,
#     method = "spearman-partial-correlation-slow",
#     height = 500,
#     width = 756,
#     parameter_labels = paste0("parm", 1:15)
#   )

## ----eval = FALSE-------------------------------------------------------------
#  get.tornado.table(
#     outcome.variable = "AR",
#     parameters = parms.tried.df,
#     outcomes = outcomes.summary.df,
#     method = "spearman-partial-correlation-slow"
#   )

